package com.lucas.estoque.repository;

import com.lucas.estoque.entity.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository extends JpaRepository<Categoria, Long> {

    <S extends Categoria> boolean existsByNomeIgnoreCase(String nome);


}
